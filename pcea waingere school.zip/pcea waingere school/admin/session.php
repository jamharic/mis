<?php
session_start();
if(!isset($_SESSION["UserID"])){
	header("location:index.php");
	exit();
	}



 include_once ("../db_conn/conn.php");

  $loggedin=$_SESSION['UserID'];
$query="select * from admins where UserID= $loggedin ";
$query_run=mysql_query($query);
while($row=mysql_fetch_assoc($query_run))
{
$Login_user= $row['Email_addr'];		
		
		
		
}
 
 ?>