<?php
include_once("session.php");

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>.::AddAdmin</title>
<link rel="stylesheet" href="../sty/css.css" type="text/css">


</head>

<body >

<?php
include_once ("adminheader.php");
?>
<br>
<div id="slab">
<fieldset>
<form action="#" method="POST">
<table align="center">
<tr><th align="center">+Add Admin</th></tr>
<tr><td>Name</td><td><input type="text" name="name" placeholder="--Name--" required  ></td></tr>
<tr><td>Email Addr</td><td><input type="text" name="email" placeholder="--Ename--" required></td></tr>

<tr><td>Gender</td><td><input type="radio" name="sex" value="male"> Male
<br>
<input type="radio" name="sex" value="female"> Female</td></tr>
<tr><td>Address</td><td><textarea></textarea></td></tr>
<tr><td>Password</td><td><input type="password" name="Adpass" placeholder="******" required/></td></tr>
<tr><td>confirm password</td><td><input type="password" name="conapass" placeholder="******" required/></td></tr>
<tr><td align="center"><input type="submit" name="Add" value="Add Admin"  style="border-radius:20px;box-shadow:1px 12px 12px 1px #666666;text-align:center; background-color:#03F; width:100px;"></td></tr>
</table>
</form>
</fieldset>
</div>
 
<?php
include_once("../footer.php")
?>
</div>
</body>
</html>