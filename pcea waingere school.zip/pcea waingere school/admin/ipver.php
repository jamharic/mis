
<?php
include_once("session.php");
$ip=$_SERVER['REMOTE_ADDR'];


$sql="SELECT 'ip' FROM admins WHERE ip='$ip'  ";
if($query=mysql_query($sql)){
	$query_rows=mysql_num_rows($query);
	if($query_rows==1){
		header("Location:dashboard.php");
	}
	else if($query_rows==0){
		header("location:logout.php");
		
		}
}
?>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
</body>
</html>