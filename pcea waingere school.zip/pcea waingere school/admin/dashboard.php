<?php
include_once("session.php");

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>.::Admin Dashboard</title>
<link rel="stylesheet" href="../sty/css.css" type="text/css">


</head>

<body onLoad="hideloader()">
<div id="load"></div>
<?php
include_once ("adminheader.php");
?>
<br>
<table><tr><td align="left">
<section id="lmenu" class="link">
<h1 align="center">Admin Menu</h1>
<ul type="square"><br>
<li><a href="FinanceMod.php">Manage Finance</a></li><br>
<li><a href="index.php">Add student</a></li><br>
<li><a href="addadmin.php">Add Admin</a></li><br>
<li><a href="addstaff.php">Add Staff</a></li><br>
</ul>
</section></td>
<td align="right"><section id="rmenu">
<fieldset>
<form action="#" method="POST">
<table align="center">
<tr><th align="center">+Register Student</th></tr>
<tr><td>Surname</td><td><input type="text" name="sname" placeholder="--surname--" required  ></td></tr>
<tr><td>FirstName</td><td><input type="text" name="fname" placeholder="--Fname--" required></td><td>LastName</td><td><input type="text" name="lname" placeholder="lname" required  ></td></tr>
<tr><td>DOB</td><td><input type="date" name="dob" placeholder="--Date Of Birth--" required  ></td></tr>
<tr><td>Gender</td><td><input type="radio" name="sex" value="male"> Male
<br>
<input type="radio" name="sex" value="female"> Female</td></tr>
<tr><td>Address</td><td><textarea></textarea></td></tr>
<tr><td>Password</td><td><input type="password" name="studpass" placeholder="******" required/></td></tr>
<tr><td>confirm password</td><td><input type="password" name="conspass" placeholder="******" required/></td></tr>
<tr><td align="center"><input type="submit" name="register" value="register"  style="border-radius:20px;box-shadow:1px 12px 12px 1px #666666;text-align:center; background-color:#03F; width:100px;"></td></tr>
</table>
</form>
</fieldset>
</section>
</td></tr></table>
 
<?php
include_once("../footer.php")
?>
</div>
</body>
</html>