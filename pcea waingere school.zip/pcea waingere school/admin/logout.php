<?php
session_start();

if(isset($_SESSION['UserID']))
{
?>
<?php

$_SESSION['UserID']=" ";
session_destroy();
header("location:index.php");
	exit();
?>
<?php
}
else
{
header("location:index.php");
	exit();
}
?>