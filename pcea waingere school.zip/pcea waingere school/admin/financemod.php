<?php 
include_once("session.php");
	
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>.::Admin Dashboard</title>
<link rel="stylesheet" href="../sty/css.css" type="text/css">

</head>

<body>
<?php
include_once ("adminheader.php");
?>
<br>


<fieldset style="margin-left:350px;margin-right:350px;">
<legend align="center"><img src="../imgr/icon-admin.png" height="50px" width="50px"></legend>
<form action="#" method="post" enctype="multipart/form-data">
<table align="center">
<tr><td>Reg No</td><td><input type="text" name="id" placeholder="Reg No" Required></td></tr>
<tr><td>Full Names</td><td><input type="text" name="name" placeholder="egWanjiru James Githu" Required></td></tr>
<tr><td>Amount</td><td><input type="text" name="amnt" placeholder="eg 10,000" Required></td></tr>
<tr><td>class</td><td><input type="text" name="class" placeholder="eg 2017" Required></td></tr>
</table><br>
<input type="submit" name="id" value="pay" style="background-color:#06F; width:100px; border-radius:5px; margin-left:550px;">


</form>
</fieldset>

 
<?php
include_once("../footer.php")
?>
</body>
</html>