<?php
session_start();
if(isset($_SESSION["UserID"])){
	
header("location:dashboard.php");
exit();
}
?>
<?php
if(isset($_POST["email"])&&isset($_POST["pswd"])){
		
		$email=preg_replace('#[^A-Za-z0-9]#i','',$_POST["email"]);
		$password=preg_replace('#[^A-Za-z0-9]#i','',$_POST["pswd"]); 
include "../db_conn/conn.php";
$sql="SELECT 'UserID' FROM admins WHERE Email_addr='$email' AND password='$password' LIMIT 1";
if($query=mysql_query($sql)){
	$query_rows=mysql_num_rows($query);
	if($query_rows==1){
		$id=mysql_result($query,0,'UserID');
		$_SESSION['UserID']=$id;
		header("location:ipver.php");
		exit();
		}else if($query_rows==0){
			
			?><span class="error"><?php echo ucwords("OOP.Username and Password Dont Match!!!");?></span>
            <?php
            
			}
	
	
	
	
	}

	


}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>.::Admin Login</title>
<link rel="stylesheet" href="../sty/css.css" type="text/css">
</head>

<body>
<div id="titl">
<p align="center">School Admin Login </p>
</div>
<div id="logform">
<fieldset>
<legend align="center">
<img src="../imgr/Admin.png" width="70px" height="70px">
</legend>
<form action="index.php" method="POST" >
<table>
<tr><td>Username</td><td><input type="text" name="email" placeholder="Username"><br></td></tr>
<tr><td>Password</td><td><input type="password" name="pswd" placeholder="******" ></td></tr>
<tr><td><input type="submit" name="sbmt" value="login"/></td></tr>
</table>
</form>
</fieldset>
</div>
</body>
</html>