<!doctype html>
<html>
<head>
<meta charset="utf-8">

</head>

<body>
<form method="post" action="#" enctype="multipart/form-data">
<table style="border-radius:30px;"><tr><td>Name</td><td><input type="text" name="name" placeholder="name" required/></td></tr>
<tr><td>Email.Addr</td><td><input type="text" name="email" placeholder="example@gmail.com" required/></td></tr>
<tr><td>Enquiry</td> <td><textarea required></textarea></td></tr>
<tr><td><input type="submit" name="submit" value="send"</td></tr></table>
</form>
</body>
</html>