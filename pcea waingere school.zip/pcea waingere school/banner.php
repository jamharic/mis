<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link href="sty/css.css" rel="stylesheet" type="text/css">

<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>

</head>

<body>
<div id="banner"><table><tr><td align="left" >
<div id="wowslider-container1">
<div class="ws_images"><ul>
		<li><img src="data1/images/1546259.jpg" alt="1546259" title="1546259" id="wows1_0"/></li>
		<li><img src="data1/images/c.jpg" alt="c" title="c" id="wows1_1"/></li>
		<li><img src="data1/images/export_ch4_pt5.jpg" alt="Export_Ch4_Pt5" title="Export_Ch4_Pt5" id="wows1_2"/></li>
		<li><img src="data1/images/financemanagement.jpg" alt="finance-management" title="finance-management" id="wows1_3"/></li>
		<li><a href="http://wowslider.com"><img src="data1/images/logo.jpg" alt="http://wowslider.com/" title="logo" id="wows1_4"/></a></li>
		<li><img src="data1/images/safari.jpg" alt="safari" title="safari" id="wows1_5"/></li>
	</ul></div>
	<div class="ws_bullets"><div>
		<a href="#" title="1546259"><span><img src="data1/tooltips/1546259.jpg" alt="1546259"/>1</span></a>
		<a href="#" title="c"><span><img src="data1/tooltips/c.jpg" alt="c"/>2</span></a>
		<a href="#" title="Export_Ch4_Pt5"><span><img src="data1/tooltips/export_ch4_pt5.jpg" alt="Export_Ch4_Pt5"/>3</span></a>
		<a href="#" title="finance-management"><span><img src="data1/tooltips/financemanagement.jpg" alt="finance-management"/>4</span></a>
		<a href="#" title="logo"><span><img src="data1/tooltips/logo.jpg" alt="logo"/>5</span></a>
		<a href="#" title="safari"><span><img src="data1/tooltips/safari.jpg" alt="safari"/>6</span></a>
	</div></div><div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.com/vi">slider</a> by WOWSlider.com v8.7</div>
<div class="ws_shadow"></div>
</div>	
<script type="text/javascript" src="engine1/wowslider.js"></script>
<script type="text/javascript" src="engine1/script.js"></script>
</td><td  width="450px" height="250px" style="color:#00C;box-shadow:1px 10px 10px 1px ;"><ol>
<li type="square">Nature Children to become important people in society</li>
<li type="square">Help children grow all rounded</li>
<li type="square">Inspire students</li>
<li type="square">Prepare students for they are the future leaders</li>

</ol></td></tr></table>
</div>

</body>
</html>