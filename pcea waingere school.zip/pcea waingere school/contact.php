<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>.::Contact Us</title>
<link href="sty/css.css" rel="stylesheet" type="text/css">
</head>
<body>
<?php include_once ("title.php")?>
<?php include_once ("header.php")?>
<div id="cont">
<table><tr><td align="left" width="350px">
<h2 align="center">Email Address</h2>
<h4 align="center" >WaingerePcea@gmail.com</h4>
<h4 align="center" style="color:#F00;">info@waingereschool.edu</h4></td><td align="center" width="350px">
<h2 align="center">Phone No</h2>
<h4 align="center" >+254-720-125-801</h4>
<h4 align="center" style="color:#0C0;">+254-735-000-111</h4>


</td><td align="right">
<h2 align="center">PO BOX</h2>
<h4 align="center" style="color:#F00;" >300-199 Githunguri</h4>
<h4 align="center" >KIAMBU</h4>

</td></tr>
<td align="center" style="color:#F00;"><h3 align="center">Our offices are open from Mon-Friday from 8AM-4PM</h3></td><td></td><td><img src="imgr/1467061598_twitter.png" height="50px" width="50px">  <img src="imgr/1467061618_facebook.png" width="50px" height="50px"> <img src="imgr/1467061634_linkedin.png" width="50px" height="50px"></td></tr>
</table>
</div>
<div id="infor">
Write To us...
<?php include_once ("engine1/inform.php")?>
</div>
<?php include_once ("footer.php")?>
</body>
</html>