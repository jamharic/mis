<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link href="sty/css.css" rel="stylesheet" type="text/css">
<style>
#te{
	border:thin;
	border-radius:20px;
	width:450px;
	height:250px;
	border-color:#00C;
	border-style:solid;
	box-shadow:1px 12px 12px 1px #06F;
	text-align:center;
	
	}
	#te1{
	border:thin;
	border-radius:20px;
	width:450px;
	height:250px;
	border-color:#00C;
	border-style:solid;
	box-shadow:1px 12px 12px 1px #06F;
	text-align:center;
	margin-left:30px;
	
	
	
	}
</style>
</head>

<body>
<div id="bann2" >
<table><tr><td><div id="te"><h2>Upcoming Events</h2></div></td><td><div id="te1" class="link"><h3>PORTAL</h3>
<br><a href="student/index.php">Students portal</a><br><a href="staff/index.php">Staff portal</a><br><a href="admin/index.php">Admin Portal</a></div></td></tr></table>
</div>
</body>
</html>