<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link href="../css.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id="title">
<h2 align="center">PCEA WAINGERE PRIMARY SCHOOL</h2>
<h3 align="center">Comitted To Serve</h3>
<p align="center"><img src="imgr/telephone120.png" width="50px" height="50px"></p><p align="center">+254-125-801</p>

</div>
</body>
</html>