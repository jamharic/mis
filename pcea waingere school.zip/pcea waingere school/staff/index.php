<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>.::Staff Login Login</title>
<link rel="stylesheet" href="../sty/css.css" type="text/css">
</head>

<body>
<div id="titl">
<p align="center">Staff Login </p>
</div>
<div id="logform">
<fieldset>
<legend align="center">
<img src="../imgr/login_lock.png" width="50px" height="50px">
</legend>
<form action="#" method="post" enctype="application/x-www-form-urlencoded">
<table>
<tr><td>Username</td><td><input type="text" name="email" placeholder="Username"><br></td></tr>
<tr><td>Password</td><td><input type="password" name="pswd" placeholder="password"></td></tr>
<tr><td><input type="submit" name="sbmt" value="login"/></td></tr>
</table>
</form>
</fieldset>
</div>
</body>
</html>