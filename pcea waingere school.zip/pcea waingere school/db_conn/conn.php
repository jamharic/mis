<?php
$con=mysql_connect("localhost","root","");
mysql_select_db("school_db",$con);
?>