<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>.::PCEA WAINGERE PRIMARY SCHOOL</title>

</head>

<body>
<?php include_once ("title.php")?>
<?php include_once ("header.php")?>
<br>
<?php include_once("banner.php")?>

<?php include_once ("bann2.php")?>
<?php include_once ("footer.php")?>
</body>
</html>