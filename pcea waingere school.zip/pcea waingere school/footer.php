<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link href="../sty/css.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id="foot">
<p align="center">&copy;2016 PCEA WAINGERE SCHOOL</p>
</div>
</body>
</html>