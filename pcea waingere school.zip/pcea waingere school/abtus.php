<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>.::About us</title>
<link rel="stylesheet" href="sty/css.css" type="text/css"/>
</head>

<body>
<?php include_once ("title.php")?>
<?php include_once ("header.php")?>
<?php include_once ("footer.php")?>
</body>
</html>